   vid = document.getElementById( "video1" );
   addEvent( vid, "click", divClickHandler );