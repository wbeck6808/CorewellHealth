// optional TSCC ActiveX install object.   
document.writeln('<object width="0" height="0" classid="clsid:74F5614A-8A8C-43B4-8CC2-4B4EFAF4A6C5" codebase="http://www.techsmith.com/codec/tsccinst.cab#Version=2,0,4,0"></object>');
		